<?php
$exchangeRates = [
    'USD' => ['USD' => 1.0, 'CAD' => 1.25, 'EUR' => 0.93],
    'CAD' => ['USD' => 0.80, 'CAD' => 1.0, 'EUR' => 0.74],
    'EUR' => ['USD' => 1.08, 'CAD' => 1.35, 'EUR' => 1.0]
];

$amount = $fromCurrency = $toCurrency = $result = "";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['amount']) && isset($_GET['fromCurrency']) && isset($_GET['toCurrency'])) {
    $amount = $_GET['amount'];
    $fromCurrency = $_GET['fromCurrency'];
    $toCurrency = $_GET['toCurrency'];

    // Perform conversion
    if (isset($exchangeRates[$fromCurrency][$toCurrency])) {
        $convertedAmount = $amount * $exchangeRates[$fromCurrency][$toCurrency];
        $result = "Converted Amount: " . number_format($convertedAmount, 2) . " $toCurrency";
    } else {
        $result = "Conversion rate not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Currency Converter</title>
</head>
<body>

<h2>Currency Converter</h2>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="GET">
    <table>
        <tr>
            <td>Amount:</td>
            <td><input type="text" name="amount" value="<?php echo $amount; ?>"/></td>
        </tr>
        <tr>
            <td>From Currency:</td>
            <td>
                <select name="fromCurrency">
                    <option value="USD" <?php if ($fromCurrency == "USD") echo "selected"; ?>>USD</option>
                    <option value="CAD" <?php if ($fromCurrency == "CAD") echo "selected"; ?>>CAD</option>
                    <option value="EUR" <?php if ($fromCurrency == "EUR") echo "selected"; ?>>EUR</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>To Currency:</td>
            <td>
                <select name="toCurrency">
                    <option value="USD" <?php if ($toCurrency == "USD") echo "selected"; ?>>USD</option>
                    <option value="CAD" <?php if ($toCurrency == "CAD") echo "selected"; ?>>CAD</option>
                    <option value="EUR" <?php if ($toCurrency == "EUR") echo "selected"; ?>>EUR</option>
                </select>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="Convert"/></td>
        </tr>
    </table>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['amount'])) {
    echo "<h3>$result</h3>";
}
?>

</body>
</html>
